// App.js
import React from "react";
import Table from "./Table";

const App = () => <Table />;

export default App;
